// config
const config = require('./' + process.env.NODE_ENV)
module.exports = config